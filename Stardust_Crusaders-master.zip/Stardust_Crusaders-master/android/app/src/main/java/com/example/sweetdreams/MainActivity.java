package com.example.sweetdreams;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
