enum UnitType{
  WAKE, BED, AM, PM
}