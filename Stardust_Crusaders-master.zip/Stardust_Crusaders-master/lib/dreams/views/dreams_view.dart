import '../viewmodel/dreams_viewmodel.dart';
class UNITSView {
  void updateMinute({required String minute}){}
  void updateUnit(int value){}
  void updateHour({required String hour}){}
  void updateResultValue(String resultValue){}
  void updateTimeString(String timeString){}
  void updateMessage(String message){}
  void updateSleepMinute({required String sleepMinute}){}
  void updateSleepHour({required String sleepHour}){}
  void updateTimeUnit(int value){}
}
